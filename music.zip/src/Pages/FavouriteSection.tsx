import Card from "../Component/SubComponent/Card";

const FavouriteSection = () => {
  return (
    <section id="favouriteSection" className="mx-5 my-3 mainBody">
      <div className="title">FavouriteSection</div>
      {/* <div className="d-flex" style={{ marginLeft: "30px" }}>
        {[1, 2, 3, 4, 5].map((ele) => {
          return <Card />;
        })}
      </div> */}
    </section>
  );
};

export default FavouriteSection;
